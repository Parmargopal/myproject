public class pattern8 {
    public static void main(String[] args) {
        int i,j,n=5;
        for (i=1;i<=5;i++)
        {
            for (j=i;j<=5;j++)
            {
                System.out.print(j);
            }
            System.out.println();
        }
    }
}
