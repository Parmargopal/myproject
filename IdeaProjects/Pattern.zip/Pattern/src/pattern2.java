public class pattern2 {
    public static void main(String[] args) {
        int i,j,k;
        for (i=5;i>=1;i--)
        {
            for (k=5;k>i;k--)
            {
                System.out.print(k);
            }
            for (j=1;j<=i;j++)
            {
                System.out.print(i);
            }
            System.out.println();
        }
    }
}
