import java.io.IOException;
import org.apache.lucene.analysis.standard.StandardAnalyzer;
import org.apache.lucene.document.Document;
import org.apache.lucene.document.Field;
import org.apache.lucene.document.TextField;
import org.apache.lucene.index.*;
import org.apache.lucene.queryparser.classic.ParseException;
import org.apache.lucene.search.*;
import org.apache.lucene.store.Directory;
import org.apache.lucene.store.RAMDirectory;
class abc {
    public static void main(String[] args) throws IOException, ParseException {
        StandardAnalyzer analyzer = new StandardAnalyzer();
        Directory dic = new RAMDirectory();
        IndexWriterConfig iwc=new IndexWriterConfig(analyzer);
        IndexWriter w=new IndexWriter(dic,iwc);
        addDoc(w,"gopal abc","ec1");
        addDoc(w,"parmar","ec2");
        addDoc(w,"gopal xyz","ec3");
        addDoc(w,"parmar abc","ec4");
        addDoc(w,"parmar xyz","ec5");
        w.close();

        Term term=new Term("name","gopal");
        Query q=new TermQuery(term);


        IndexReader reader = DirectoryReader.open(dic);
        IndexSearcher searcher = new IndexSearcher(reader);
        TopDocs docs = searcher.search(q, 100);
        ScoreDoc[] hits = docs.scoreDocs;

        for (int i=0;i<hits.length;++i)
        {
            int docId = hits[i].doc;
            Document d = searcher.doc(docId);
            System.out.println(d.get("name"));
        }
        reader.close();

    }

    private static void addDoc(IndexWriter w, String name, String rollno) throws IOException{
        Document doc = new Document();
        doc.add(new TextField("name", name, Field.Store.YES));
        doc.add(new TextField("rollno", rollno, Field.Store.YES));
        w.addDocument(doc);


    }
}
